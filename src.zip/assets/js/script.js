window.onload = function () {
    var video = document.getElementById("myVideo");
    video.play();
};
